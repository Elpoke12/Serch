﻿using System;

namespace Busqueda_Secuencial
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declaramos estas variables, para la posicion
            int Valor, i = 0, Posicion = 0;
            //Inicialisamos nuestro vector
            int[] Vektor = { 69, 1, 6, 3, 2, 666, 39, 24, 74, 70 };
            //Este sera nuestro buscador
            bool Find = false;
            //Esto solo despliega el vector
            for (int f = 0; f < Vektor.Length; f++)
            {
                Console.WriteLine(Vektor[f]);
            }
            Console.WriteLine("////////////////////////////////");
            Console.Write("Ingrese un dato que desa buscar: ");
            Valor = int.Parse(Console.ReadLine());

            //Ahora el while empezara a buscar en el vector mientras la posicion sea menor a 10
            while (!(Find) && i < 10)
            {
                if (Valor == Vektor[i])
                {
                    Find = true;
                    Posicion = i; //Aqui le daremos la posicion del vector al numero

                }
                i = i + 1;

            }
            if (Find)//Desplegamos si el encontro el elmento
            {
                Console.WriteLine("Elemento Encontrado:{0},en la posicion {1} ", Valor, Posicion);
            }
            else//De lo contrario
            {
                Console.Write("Elemento no encontrado");
            }
            



        }
    }
}
